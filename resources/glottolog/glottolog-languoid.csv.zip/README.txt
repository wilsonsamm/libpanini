
Glottolog 2.6 data download
===========================

Data of Glottolog 2.6 is published under the following license:
http://creativecommons.org/licenses/by-sa/3.0/

It should be cited as

Hammarström, Harald & Forkel, Robert & Haspelmath, Martin & Bank, Sebastian. 2015.
Glottolog 2.6.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://glottolog.org, Accessed on 2015-10-06.)
